#!/usr/bin/env bash
set -euo pipefail

# Modos:
#   ./deploy-ism.sh --infra-only   # namespace + Services + Ingress; sem Pods
#   ./deploy-ism.sh <BUILD_ID>     # Deployments + Services + Ingress; exige imagens e Secret

AWS_PROFILE="${AWS_PROFILE:-uze}"
AWS_REGION="${AWS_REGION:-us-east-1}"
EKS_CLUSTER="${EKS_CLUSTER:-cluster-uze}"
NODEGROUP="${NODEGROUP:-workers}"
EXPECTED_ACCOUNT="189065795615"
KUBECTL_BIN="${KUBECTL_BIN:-kubectl.exe}"
MODE=""
BUILD_ID=""

if [[ $# -eq 1 && "$1" == "--infra-only" ]]; then
  MODE="infra-only"
elif [[ $# -eq 1 && "$1" =~ ^[0-9]+$ ]]; then
  MODE="full"
  BUILD_ID="$1"
else
  echo "Uso: $0 --infra-only | <BUILD_ID numérico do Azure DevOps>" >&2
  echo "  --infra-only: Namespace, Services e Ingress, sem workloads (não precisa de ECR/Secret)." >&2
  echo "  <BUILD_ID>: deploy completo; as seis tags <componente>-v<BUILD_ID> precisam existir em uze-crm-ism-prd." >&2
  exit 2
fi

for bin in aws jq sed; do
  command -v "$bin" >/dev/null 2>&1 || {
    echo "ERRO: comando obrigatório não encontrado: $bin" >&2
    exit 1
  }
done
command -v "$KUBECTL_BIN" >/dev/null 2>&1 || {
  echo "ERRO: kubectl não encontrado: $KUBECTL_BIN" >&2
  exit 1
}

ACCOUNT="$(aws sts get-caller-identity --profile "$AWS_PROFILE" --query Account --output text)"
if [[ "$ACCOUNT" != "$EXPECTED_ACCOUNT" ]]; then
  echo "ERRO: perfil $AWS_PROFILE está na conta $ACCOUNT; esperada $EXPECTED_ACCOUNT." >&2
  exit 1
fi

CLUSTER_STATUS="$(aws eks describe-cluster \
  --profile "$AWS_PROFILE" \
  --region "$AWS_REGION" \
  --name "$EKS_CLUSTER" \
  --query 'cluster.status' \
  --output text)"
[[ "$CLUSTER_STATUS" == "ACTIVE" ]] || {
  echo "ERRO: cluster está $CLUSTER_STATUS, não ACTIVE." >&2
  exit 1
}

CURRENT_CONTEXT="$("$KUBECTL_BIN" config current-context)"
EXPECTED_CONTEXT="arn:aws:eks:${AWS_REGION}:${EXPECTED_ACCOUNT}:cluster/${EKS_CLUSTER}"
if [[ "$CURRENT_CONTEXT" != "$EXPECTED_CONTEXT" ]]; then
  echo "ERRO: kubectl context incorreto." >&2
  echo "Atual:    $CURRENT_CONTEXT" >&2
  echo "Esperado: $EXPECTED_CONTEXT" >&2
  exit 1
fi

NODEGROUP_STATUS="$(aws eks describe-nodegroup \
  --profile "$AWS_PROFILE" \
  --region "$AWS_REGION" \
  --cluster-name "$EKS_CLUSTER" \
  --nodegroup-name "$NODEGROUP" \
  --query 'nodegroup.status' \
  --output text)"
DESIRED_NODES="$(aws eks describe-nodegroup \
  --profile "$AWS_PROFILE" \
  --region "$AWS_REGION" \
  --cluster-name "$EKS_CLUSTER" \
  --nodegroup-name "$NODEGROUP" \
  --query 'nodegroup.scalingConfig.desiredSize' \
  --output text)"
[[ "$NODEGROUP_STATUS" == "ACTIVE" && "$DESIRED_NODES" == "6" ]] || {
  echo "ERRO: node group $NODEGROUP status=$NODEGROUP_STATUS desired=$DESIRED_NODES; esperado ACTIVE/6." >&2
  exit 1
}

READY_NODES="$("$KUBECTL_BIN" get nodes \
  -l eks.amazonaws.com/nodegroup="$NODEGROUP" \
  -o json | jq '[.items[] | select(any(.status.conditions[]; .type == "Ready" and .status == "True"))] | length')"
[[ "$READY_NODES" == "6" ]] || {
  echo "ERRO: encontrados $READY_NODES nós Ready no node group $NODEGROUP; esperado 6." >&2
  exit 1
}

"$KUBECTL_BIN" get ingressclass nginx >/dev/null
INGRESS_CONTROLLER="$("$KUBECTL_BIN" get ingressclass nginx -o jsonpath='{.spec.controller}')"
[[ "$INGRESS_CONTROLLER" == "k8s.io/ingress-nginx" ]] || {
  echo "ERRO: IngressClass nginx aponta para controller inesperado: $INGRESS_CONTROLLER" >&2
  exit 1
}
if ! "$KUBECTL_BIN" get clusterissuer letsencrypt-prod >/dev/null 2>&1; then
  echo "AVISO: ClusterIssuer letsencrypt-prod não encontrado; Ingress será criado, mas TLS não será emitido até corrigir o issuer." >&2
else
  ISSUER_READY="$("$KUBECTL_BIN" get clusterissuer letsencrypt-prod \
    -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}')"
  if [[ "$ISSUER_READY" != "True" ]]; then
    echo "AVISO: ClusterIssuer letsencrypt-prod não está Ready; prosseguindo sem garantia de TLS." >&2
  fi
fi
echo "AVISO: DNS e emissão/validação TLS não bloqueiam; HTTPS pode falhar até DNS público e ACME estarem prontos." >&2

HOSTS_JSON='["ism-crm.collectioncenter.com.br","ism-api-crm.collectioncenter.com.br","ism-webhooks-crm.collectioncenter.com.br"]'
INGRESS_JSON="$("$KUBECTL_BIN" get ingress -A -o json)"
HOST_CONFLICTS="$(printf '%s' "$INGRESS_JSON" | jq -r \
  --arg namespace ism \
  --arg name ism-crm-ingress \
  --argjson wanted "$HOSTS_JSON" '
    def overlaps($existing; $requested):
      ($existing == $requested) or
      (if ($existing | startswith("*.")) then
         (($requested | split(".") | length) == ($existing | split(".") | length)) and
         (($requested | split(".") | .[1:] | join(".")) == ($existing | ltrimstr("*.")))
       else false end);
    .items[] as $ing
    | select(
        (($ing.metadata.namespace != $namespace) or ($ing.metadata.name != $name))
        and (
          ($ing.metadata.namespace != $namespace)
          or ((($ing.metadata.name // "") | startswith("cm-acme-http-solver-")) | not)
        )
      )
    | $ing.spec.rules[]?
    | select(.host as $host | any($wanted[]; overlaps($host; .)))
    | "\($ing.metadata.namespace)/\($ing.metadata.name) host=\(.host)"
  ')"
if [[ -n "$HOST_CONFLICTS" ]]; then
  echo "ERRO: hostname(s) ISM já declarado(s) em outro Ingress; não aplicarei rotas conflitantes:" >&2
  printf '%s\n' "$HOST_CONFLICTS" >&2
  exit 1
fi

if "$KUBECTL_BIN" get ingress ism-crm-ingress -n ism >/dev/null 2>&1; then
  INGRESS_OWNER="$("$KUBECTL_BIN" get ingress ism-crm-ingress -n ism \
    -o jsonpath='{.metadata.labels.app\.kubernetes\.io/managed-by}')"
  [[ "$INGRESS_OWNER" == "ism-k8s" ]] || {
    echo "ERRO: ism/ism-crm-ingress já existe sem a label de ownership ism-k8s; revisar manualmente." >&2
    exit 1
  }
fi

if "$KUBECTL_BIN" get namespace ism >/dev/null 2>&1; then
  NAMESPACE_TENANT="$("$KUBECTL_BIN" get namespace ism -o jsonpath='{.metadata.labels.tenant}')"
  [[ "$NAMESPACE_TENANT" == "ism" ]] || {
    echo "ERRO: namespace ism existe, mas não está identificado com label tenant=ism; revisar manualmente." >&2
    exit 1
  }
fi

ECR_REPOSITORY='uze-crm-ism-prd'
IMAGE_TAGS=(front application webapi webhooks workers boleto)
if [[ "$MODE" == "full" ]]; then
  MISSING_IMAGES=()
  for component in "${IMAGE_TAGS[@]}"; do
    image_tag="${component}-v${BUILD_ID}"
    if aws ecr describe-images \
      --profile "$AWS_PROFILE" \
      --region "$AWS_REGION" \
      --repository-name "$ECR_REPOSITORY" \
      --image-ids imageTag="$image_tag" >/dev/null 2>&1; then
      echo "ECR OK: ${ECR_REPOSITORY}:${image_tag}"
    else
      MISSING_IMAGES+=("${ECR_REPOSITORY}:${image_tag} (repositório/tag ausente ou sem permissão de leitura)")
    fi
  done
  if ((${#MISSING_IMAGES[@]} > 0)); then
    echo "ERRO: a release do Build ID $BUILD_ID ainda não está completa no ECR; nenhum workload/Service/Ingress foi aplicado." >&2
    printf '  - %s\n' "${MISSING_IMAGES[@]}" >&2
    echo "Use o Build ID real do run do Azure DevOps, não a data do deploy; ou publique primeiro as seis tags de componente." >&2
    echo "Para criar somente Namespace, Services e Ingress sem imagens, execute: $0 --infra-only" >&2
    exit 1
  fi
fi

"$KUBECTL_BIN" apply --dry-run=server -f 00-namespace.yaml >/dev/null
"$KUBECTL_BIN" apply -f 00-namespace.yaml
"$KUBECTL_BIN" wait --for=jsonpath='{.status.phase}'=Active namespace/ism --timeout=60s

if [[ "$MODE" == "infra-only" ]]; then
  "$KUBECTL_BIN" apply --dry-run=server -f 02-services.yaml >/dev/null
  "$KUBECTL_BIN" apply --dry-run=server -f 03-ingress.yaml >/dev/null
  "$KUBECTL_BIN" apply -f 02-services.yaml
  "$KUBECTL_BIN" apply -f 03-ingress.yaml
  "$KUBECTL_BIN" get services,ingress -n ism -o wide
  echo "Bootstrap infra-only concluído: nenhum Deployment foi criado; Services estarão sem endpoints e hosts poderão retornar 503 até publicar as imagens e fazer o deploy completo." >&2
  exit 0
fi

if ! "$KUBECTL_BIN" get secret ism-crm-secrets -n ism -o json \
  | jq -e '.data | has("ConnectionStrings__Default")' >/dev/null; then
  echo "ERRO: Secret ism-crm-secrets não existe ou não contém ConnectionStrings__Default no namespace ism." >&2
  echo "Namespace foi preparado; crie/valide o Secret pelo cofre corporativo antes do deploy completo. Não coloque valores secretos neste script." >&2
  exit 1
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
sed "s|\\\$(Build\.BuildId)|${BUILD_ID}|g" 01-deployments.yaml > "$TMP_DIR/01-deployments.yaml"
if grep -Fq '$(Build.BuildId)' "$TMP_DIR/01-deployments.yaml"; then
  echo "ERRO: restou macro Build.BuildId sem renderização no manifesto." >&2
  exit 1
fi

"$KUBECTL_BIN" apply --dry-run=server -f 02-services.yaml >/dev/null
"$KUBECTL_BIN" apply --dry-run=server -f "$TMP_DIR/01-deployments.yaml" >/dev/null
"$KUBECTL_BIN" apply --dry-run=server -f 03-ingress.yaml >/dev/null

"$KUBECTL_BIN" apply -f 02-services.yaml
"$KUBECTL_BIN" apply -f "$TMP_DIR/01-deployments.yaml"
"$KUBECTL_BIN" apply -f 03-ingress.yaml

for deployment in \
  ism-crm-front \
  ism-crm-application \
  ism-crm-webapi \
  ism-crm-webhooks \
  ism-crm-workers \
  ism-crm-boleto-pdf-generator; do
  "$KUBECTL_BIN" rollout status "deployment/$deployment" -n ism --timeout=300s
done

"$KUBECTL_BIN" get deployments,pods,services,ingress -n ism -o wide
echo "Deploy completo ISM concluído com Build ID v$BUILD_ID. Faça os testes funcionais antes de liberar tráfego de produção."
