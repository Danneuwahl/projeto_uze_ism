#!/usr/bin/env bash
set -Eeuo pipefail

# Builds and pushes one ISM component (or all .NET backend components) to one ECR repository.
# Required environment: AWS_REGION, AWS_ACCOUNT_ID, BUILD_ID.
# Frontend also requires API_URL and MANUS_API_BASE_URL.

COMPONENT="${1:-}"
AWS_REGION="${AWS_REGION:-us-east-1}"
AWS_ACCOUNT_ID="${AWS_ACCOUNT_ID:-}"
BUILD_ID="${BUILD_ID:-}"
ECR_REPOSITORY="${ECR_REPOSITORY:-uze-crm-ism-prd}"
API_URL="${API_URL:-}"
MANUS_API_BASE_URL="${MANUS_API_BASE_URL:-}"

if [[ -z "$COMPONENT" ]]; then
  echo "Uso: $0 {frontend|backend-all|boleto}" >&2
  exit 2
fi
if [[ ! "$BUILD_ID" =~ ^[0-9]+$ ]]; then
  echo "ERRO: BUILD_ID ausente ou inválido; esperado o Build ID numérico do Azure DevOps." >&2
  exit 2
fi
if [[ ! "$AWS_ACCOUNT_ID" =~ ^[0-9]{12}$ ]]; then
  echo "ERRO: AWS_ACCOUNT_ID ausente ou inválido." >&2
  exit 2
fi
if [[ ! "$AWS_REGION" =~ ^[a-z]{2}(-gov)?-[a-z]+-[0-9]+$ ]]; then
  echo "ERRO: AWS_REGION inválida." >&2
  exit 2
fi

ACTUAL_ACCOUNT="$(aws sts get-caller-identity --query Account --output text)"
if [[ "$ACTUAL_ACCOUNT" != "$AWS_ACCOUNT_ID" ]]; then
  echo "ERRO: credencial AWS está na conta $ACTUAL_ACCOUNT; esperado $AWS_ACCOUNT_ID." >&2
  exit 1
fi

REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
IMAGE_BASE="${REGISTRY}/${ECR_REPOSITORY}"
aws ecr describe-repositories --region "$AWS_REGION" --repository-names "$ECR_REPOSITORY" >/dev/null
aws ecr get-login-password --region "$AWS_REGION" \
  | docker login --username AWS --password-stdin "$REGISTRY" >/dev/null

push_image() {
  local component_tag="$1"
  local image="${IMAGE_BASE}:${component_tag}-v${BUILD_ID}"
  docker image inspect "$image" >/dev/null
  echo "Publicando ${ECR_REPOSITORY}:${component_tag}-v${BUILD_ID}"
  docker push "$image"
}

build_backend_component() {
  local component_tag="$1"
  local project_name="$2"
  local image="${IMAGE_BASE}:${component_tag}-v${BUILD_ID}"
  docker build \
    --file backend/Dockerfile \
    --build-arg "PROJECT_NAME=${project_name}" \
    --tag "$image" \
    backend
  push_image "$component_tag"
}

case "$COMPONENT" in
  frontend)
    if [[ -z "$API_URL" || -z "$MANUS_API_BASE_URL" ]]; then
      echo "ERRO: API_URL e MANUS_API_BASE_URL são obrigatórios para o build frontend." >&2
      exit 2
    fi
    docker build \
      --target final \
      --file frontend/Dockerfile \
      --build-arg "VITE_API_URL=${API_URL}" \
      --build-arg "VITE_MANUS_API_URL=${MANUS_API_BASE_URL}" \
      --tag "${IMAGE_BASE}:front-v${BUILD_ID}" \
      frontend
    push_image front
    ;;
  backend-all)
    build_backend_component application Uze.Collection.Application.Host
    build_backend_component webapi Uze.Collection.WebApi.Host
    build_backend_component webhooks Uze.Collection.Webhooks.Host
    build_backend_component workers Uze.Collection.Workers.Host
    ;;
  boleto)
    docker build \
      --file boleto-pdf-generator/Dockerfile \
      --tag "${IMAGE_BASE}:boleto-v${BUILD_ID}" \
      boleto-pdf-generator
    push_image boleto
    ;;
  *)
    echo "ERRO: componente desconhecido: $COMPONENT. Opções: frontend, backend-all, boleto." >&2
    exit 2
    ;;
esac
